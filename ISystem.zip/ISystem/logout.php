<?php
  require_once('Config/load.php');
  if(!$session->logout()) {redirect("index.php");}
?>