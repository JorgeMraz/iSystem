<?php
  $page_title = 'Admin página de inicio';
  require_once('Config/load.php');
   page_require_level(1);
?>
<?php
 $c_categorie     = count_by_id('categories');
 $c_product       = count_by_id('products');
 $c_sale          = count_by_id('sales');
 $c_user          = count_by_id('users');
 $products_sold   = find_higest_saleing_product('10');
 $recent_products = find_recent_product_added('5');
 $recent_sales    = find_recent_sale_added('5')
?>
<?php include_once('Cuentas/header.php'); ?>

<?php include_once('Cuentas/footer.php'); ?>
