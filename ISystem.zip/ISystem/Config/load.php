<?php
// -----------------------------------------------------------------------
// DEFINE SEPERATOR ALIASES
// -----------------------------------------------------------------------
define("URL_SEPARATOR", '/');

define("DS", DIRECTORY_SEPARATOR);

// -----------------------------------------------------------------------
// DEFINE ROOT PATHS
// -----------------------------------------------------------------------
defined('SITE_ROOT')? null: define('SITE_ROOT', realpath(dirname(__FILE__)));
define("LIB_PATH_INC", SITE_ROOT.DS);


require_once(LIB_PATH_INC.'configuraciondb.php');
require_once(LIB_PATH_INC.'funciones.php');
require_once(LIB_PATH_INC.'session.php');
require_once(LIB_PATH_INC.'subida.php');
require_once(LIB_PATH_INC.'database.php');
require_once(LIB_PATH_INC.'sqldb.php');

?>