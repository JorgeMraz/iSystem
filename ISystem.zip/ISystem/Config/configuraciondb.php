<?php

  define( 'DB_HOST', 'localhost' );          //Establecer host de base de datos
  define( 'DB_USER', 'root' );             // Establecer user de base de datos
  define( 'DB_PASS', '' );             // Establecer password de base de datos
  define( 'DB_NAME', 'inventariobd' );        // Establecer nombre de base de datos

?>